document.getElementById('envelope').onclick = function() {
    this.classList.toggle('open');
};